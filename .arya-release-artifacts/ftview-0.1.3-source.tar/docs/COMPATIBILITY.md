# Compatibility and limitations

| Area | Supported scope |
| --- | --- |
| Edition | ME engineering adapter; SE requires its own documentation/adapter |
| Host | Arya DSH/Cordis tools and skills |
| Engine | Independent Python/lxml JSON interface |
| Graphics | Existing attribute edits and validated new display templates |
| Tags | Supported `###002` CSV parsing/upsert |
| PLC | Offline controller/program scopes, available members/types, arrays, bits |
| Import | Studio wizard demonstrated; native execution requires qualification |
| Terminal | Build evidence; transfer/live writes outside this release |

Use matching locally installed ME schemas. Schema suffixes are not marketing releases. Unsupported schemas fail. Microsoft XSD regex escapes may be normalized in memory; original hashes are retained and installed files are untouched.

Graphics XML omits some native content; picture/OLE limitations require native inspection and backups. Unknown exported XML is preserved by targeted edits, but export equality does not prove native-only object preservation. CSV upsert preserves supported rows/encoding while possibly normalizing quoting/comment layout.

Shortcut mappings are explicit inputs. Missing shortcuts, indirect references, aliases, and absent definitions remain unresolved. Controller-name matches do not establish online equivalence. Design/Runtime communication assignments are inspected separately.

Rockwell documents ME 15+ utility support in [Add Component Tool](https://www.rockwellautomation.com/en-nl/docs/factorytalk-view/16-00-00/me-help-ditamap/-ftvstu--main-window/add-component-se-add-cpnt-tool.html). Documentation support is distinct from local qualification for the actual executable/category. A real import/re-export probe with retained diagnostics is required.

## Roadmap

Separate SE adapter; MCP wrapper around the existing engine; direct Studio 5000 integration; additional export formats/native categories with retained acceptance evidence. These are planned milestones, not current capabilities.
