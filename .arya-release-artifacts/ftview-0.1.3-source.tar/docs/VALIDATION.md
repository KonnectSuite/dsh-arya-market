# Validation and release evidence

## Automated checks

Version 0.1.3 passed 20 Python engine tests and nine Node cases locally. The Node suite invokes the Python suite: 29 checks, not two independent Python runs. Fixtures are synthetic exports and opaque native-file placeholders.

Coverage includes malformed XML/CSV, blocked DTDs, schema failures, scoped PLC references, unresolved definitions, dependency/payload integrity, stale export/native baselines, preservation of supported content, partial import outcomes, errors despite exit code zero, and utility qualification invalidation.

The four 0.1.3 regressions address workspace/artifact roots before mutation, legacy unsafe registrations, nested `.ftview`, nested source/fresh roots, and unrelated evidence that must not stale a clean baseline.

Run `npm test` after installing requirements. CI exercises Windows/Linux with Node.js 22 and Python 3.12. Synthetic CI does not qualify vendor operations.

## Anonymized local pilot

Customer files, screenshots, runtimes, application names, addresses, and workstation paths remain local.

| Check | Observed evidence |
| --- | --- |
| Restore | User restored a uniquely named ME development copy |
| Product/schema | ME Studio 16.00.00 and matching installed ME schema |
| Host | Live Arya session advertised ten tools and invoked discovery/analysis |
| New display | Numeric indicator/return navigation imported via wizard and survived re-export |
| Targeted edit | One scale-caption attribute changed; other supported content preserved |
| Export comparison | All 13 supplied displays matched expected semantics |
| Visual review | Display and communication-assignment screenshots retained |
| Runtime | Separate v15 artifact retained following user-reported build completion |
| Vendor utility | Probe failed; no accepted native execution qualification |
| 0.1.3 host | Isolated installed services loaded tools/skill and verified existing exports |

## Not established

Functional terminal behavior, live numeric updates, exact complete hardware/firmware compatibility, equivalence of offline PLC definitions to the current online program, and preservation of native-only/unexported content remain unverified. Native utility import is not qualified. The running Arya chat loading 0.1.3 after restart is distinct from isolated host acceptance.

Keep static findings, export equality, visual inspection, runtime creation, configured communications, and functional acceptance as separate evidence. A retained MER with caller-supplied target does not establish its embedded version.
