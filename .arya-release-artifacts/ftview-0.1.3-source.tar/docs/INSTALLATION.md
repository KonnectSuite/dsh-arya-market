# Installation and operation

## Requirements

| Component | Requirement |
| --- | --- |
| Host | Arya DSH/Cordis tools and skills services |
| JavaScript | Node.js 20+; no external JavaScript package dependencies |
| Python | 3.10+ with `lxml>=6.0,<7` |
| Studio workflows | Licensed FactoryTalk View Studio ME on Windows |
| Validation | Matching locally installed ME XSD files |
| Desktop operation | User-operated Studio or an independently connected computer-use companion |

The plugin does not install FactoryTalk or provide a license. Product registry information establishes marketing release evidence; DLL versions do not establish marketing versions or license status.

## Prepare a checkout

```powershell
python -m pip install -r requirements.txt
npm test
node preflight.mjs
npm pack
```

Tests use synthetic exports. Preflight checks bundle resources and the selected interpreter; it does not prove Studio import or running-chat registration.

## Install in Arya

Install the checkout or packed tarball through the plugin manager. The Arya host operation is:

```text
plugin_manager install_bundle file:C:\path\to\dsh-factorytalk-view-use
```

This is a host operation, not a PowerShell command. Use the installation interface supplied by your Arya build. Let the manager update bundle/dependency records; do not manually rewrite profiles or create node_modules junctions. Restart/reload when requested.

Ask Arya to load the skill and actually call `ftview_environment`. Request the Studio engineering guide and check the baseline-folder and destination-selection rules. Successful isolated registration does not prove the running chat loaded the release.

## Runtime and workspace selection

`FTVIEW_PYTHON` selects an explicit interpreter. Otherwise, the wrapper checks Arya's bundled Python, the local Codex bundled Python, then `python` on PATH. Install lxml in the selected interpreter.

The workspace comes from the attached session. Standalone calls can use `FTVIEW_WORKSPACE` or the process directory. Attached sessions without a resolvable absolute workspace fail rather than using a host-profile fallback.

## Troubleshooting

| Failure | Action |
| --- | --- |
| Python/lxml startup | Install requirements in the selected interpreter |
| `WORKSPACE_UNRESOLVED` | Attach the session to an absolute local workspace |
| `PATH_OUTSIDE_WORKSPACE` | Place stage exports and packages inside that session workspace |
| Artifact overlap/containment | Select a clean export-only child folder outside `.ftview` |
| `STAGE_ALREADY_REGISTERED` | Reuse the registered stage; do not move its marker to bypass a guard |
| Stale baseline | Save/export current content and prepare a new package |
| Native execute refuses | Use the documented Studio wizard; qualification is not a permission flag |

Save pending Studio work before establishing the baseline. Export folders should contain only intended saved exports and vendor-generated indexes/logs.
