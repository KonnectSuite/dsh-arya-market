# ME engineering workflow

## Establish identity and exports

Discover the installed release and matching schemas. Record application, terminal catalog/series, and runtime version separately. Restore through ME Application Manager under a unique `AryaFTV_` name. Preserve the source archive and respect conversion/password restrictions.

Save pending Studio work before exporting. Use the graphics and HMI tag wizards; export applicable globals, parameters, macros, alarms, and other supported components when required. Report missing coverage.

```text
MEWorkspace/
  exports/baseline/
  exports/after-change/
  plc/
  runtime/
  evidence/
  .ftview/
```

Export folders are disjoint and contain no `.ftview`. Register the exact native directory and baseline. Do not move stage markers to bypass guards.

## Analyze and prepare

Start with compact inspection, then full detail for exact files or focused reference traces. Map shortcuts explicitly to offline L5X and retain identity evidence. Do not guess replacement references.

Prepare only intended edits with exact XPath/old-value conditions, real dependencies, and a reviewable expected result. Keep complete native backups. XML serialization may normalize formatting; semantic comparison determines supported-content differences.

## Import an existing display

1. Run preflight immediately before import. If baseline/dependencies changed, export again and prepare a new package.
2. Confirm the unique test application and close the destination display tab.
3. Open Graphics Import Export Wizard and choose single-display XML import.
4. Select the payload XML and explicitly choose the existing destination display.
5. Choose **Update existing objects**; check destination before Finish.
6. Retain diagnostics, reopen/inspect the result, and save.

For a new display, create/save a blank display under the intended name first, then close it. Explicitly select that destination and choose **Create new objects**. The XML filename does not select or create a destination. Check original displays and display numbers for accidental imports.

These requirements follow [Rockwell's single-display import instructions](https://www.rockwellautomation.com/en-mde/docs/factorytalk-view/16-00-00/me-help-ditamap/about-graphic-displays/graphics-import-export-wizard/import-a-single-display-xml-file.html).

Use the wizard when native execution is unqualified. Do not bypass the refusal with direct command-line invocation. Inspect application/logs after a partial failure before considering another import. Saving pending work after preparation may stale the native baseline.

## Verify and build

Export all affected supported content, preferably the complete display set, into the separate fresh folder. Verify with diagnostics and screenshots. Resolve missing, extra, or unexpected semantic differences before acceptance.

Build a uniquely named runtime at the selected compatible target version. Retain the file/hash, target selection, diagnostics, and build report. Creation is distinct from functional runtime testing and hardware qualification.

After completion, retain evidence and refresh the registered baseline from new saved Studio exports before another change. Previous packages then become stale for import.

## Completion record

Record application/archive identity, installed release/schema, export provenance, edits, preflight, import diagnostics, visual review, fresh comparison, runtime artifact/build evidence, unresolved coverage, and remaining functional/hardware acceptance.
