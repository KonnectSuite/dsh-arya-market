# Tool reference

Use absolute paths; `files` and change filenames are relative to the export root. `index.js` is the authoritative JSON schema source. Optional fields are identified below.

| Tool | Inputs | Purpose |
| --- | --- | --- |
| `ftview_environment` | None | Discover releases, schemas, help, utilities; no license/live-communication test |
| `ftview_project_inspect` | `export_root`; optional `schema_dir`, `detail`, `files` | Compact inventory by default; full object detail on request |
| `ftview_reference_trace` | `export_root`, `query`; optional `schema_dir` | Focused tag/object/navigation/parameter matches |
| `ftview_l5x_compare` | `export_root`, `shortcut_l5x`; optional `schema_dir` | Findings against explicitly mapped offline projects |
| `ftview_graphics_validate` | `file`, `schema_dir` | Matching ME XSD validation and provenance |
| `ftview_stage_register` | `application`, `project_path`, `source_archive`, `export_root`, `restoration_evidence` | Register exact restored identity; no restore operation |
| `ftview_change_prepare` | `application`, `schema_dir`, `changes`, `expected_result`; optional `dependencies` | Prepare sealed payload/manifest with matching installed schemas |
| `ftview_studio_apply` | `package`, `mode` (`preflight`/`execute`) | Baseline checks; execute additionally requires qualification |
| `ftview_verify` | `package`, `fresh_export_root`; optional `diagnostics`, `visual_evidence`, `export_file_mapping`, `runtime` | Compare fresh exports and retain evidence |
| `ftview_engineering_guide` | `topic` (`engineering`/`studio`/`formats`) | Load focused engineering guidance |

## Offline mapping

```json
{
  "export_root": "C:/Engineering/MEWorkspace/exports/baseline",
  "shortcut_l5x": {"Machine": "C:/Engineering/PLC/Machine.L5X"}
}
```

Mappings are caller-supplied contracts. Confirm Design and Runtime assignments separately. Missing definitions, indirect references, unresolved aliases, and unknown shortcut identity remain unresolved.

## Attribute change entry

```json
{
  "file": "Overview.xml",
  "kind": "graphics_attributes",
  "edits": [{
    "xpath": "/gfx/numericDisplay[@name='Speed']",
    "attribute": "width",
    "expected": "100",
    "value": "120"
  }]
}
```

Use the XPath/attribute observed in the actual export, not this example as a vendor template. Each edit selects exactly one element with the expected old value. `add_display` supplies a validated `template` path. `tag_upsert` supplies `tags` keyed by vendor CSV headings. Dependencies are actual file paths, not descriptions. See [formats](../references/formats.md).

## Runtime evidence

Optional `runtime` requires `file`, `target_version`, `terminal_model`, and `creation_evidence`. The verifier checks/hashes the supplied MER and retains caller evidence. It does not decode its embedded version, establish binary build provenance, or perform functional testing.

## Standalone requests

Send JSON on stdin to `python engine.py`:

```json
{
  "operation": "inspect",
  "workspace": "C:/Engineering/MEWorkspace",
  "args": {"export_root": "C:/Engineering/MEWorkspace/exports/baseline", "detail": "summary"}
}
```

Operations: `inspect`, `trace`, `compare_l5x`, `validate`, `stage`, `prepare`, `preflight`, `verify`. Success returns `{"ok":true,"result":...}`; failure returns `{"ok":false,"error":...,"error_type":...}` and exit code 1. Host inspection defaults to summary; standalone inspection returns full detail unless summary is requested.
