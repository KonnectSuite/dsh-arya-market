# Architecture

```mermaid
flowchart LR
  A[Arya tools and skills] --> B[index.js host adapter]
  B --> C[engine.py analysis]
  B --> D[Windows discovery bridge]
  C --> E[XML, CSV, offline L5X and local XSD]
  C --> F[Stages and sealed packages]
  G[Studio wizard] --> H[Fresh exports and diagnostics]
  H --> C
```

## Components

`index.js` registers ten contracts and delivers the skill synchronously. It resolves the calling session workspace, selects Python, wraps JSON requests, and manages the optional vendor-utility adapter. Subprocesses use argument arrays without a shell and bounded time/output.

`engine.py` owns parsing, schema validation, reference resolution, preparation, baseline checks, and verification. Its stdin/stdout protocol is host-independent so a future MCP wrapper can reuse the engine.

`bridge/discover.ps1` discovers Windows product information, utilities, schemas, and help. It is not a Studio UI automation service.

## Package lifecycle

Stage records tie a unique `AryaFTV_` application to its native directory, archive hash, export root, and caller-supplied restoration evidence. Registration does not restore or independently prove restoration.

Preparation captures export/native baselines and dependency hashes, validates supported edits, and writes payloads plus a manifest/hash under `.ftview/changes`. Preflight checks stage identity, original archive, manifest, payloads, dependencies, baselines, and schemas.

Native files are read only for hashes. Vendor-locked files can be represented by size/modification time, with reduced coverage reported. Unchanged metadata does not prove unchanged database content.

Verification compares fresh export semantics to package expectations and retains diagnostics/image references. Generated batch indexes and logs are separated from display comparisons. Image references alone are not tool-issued visual approval.

## Native execution boundary

Preflight is available without utility qualification. Execute requires a real disposable import/re-export probe for the utility hash, product release, and category. The adapter locks the application and repeats preflight before invoking the utility. Exit code zero is insufficient if logs report failure or are missing. Partial failures are retained and never automatically retried.

The validated environment has no accepted native utility qualification. The Studio wizard is the demonstrated route. Synthetic receipts only test adapter logic.

## Data boundaries

XML parsing blocks DTDs, external entities, and network retrieval. Installed schemas are never modified. No tool decodes/patches native project databases, connects to a PLC, or transfers a runtime. Offline controller-name matches do not prove current online program equivalence. Customer applications and vendor resources are outside this repository.
